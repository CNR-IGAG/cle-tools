# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		cle_cl_ac.py
# Author:	  Tarquini E.
# Created:	 22-09-2018
#-------------------------------------------------------------------------------

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.utils import *
from qgis.gui import *
from qgis.core import *
from qgis.PyQt.QtWidgets import *
import webbrowser, re


def cl_ac(dialog, layer, feature):
	ID_infra = dialog.findChild(QLineEdit,"ID_infra")
	#data_ac = dialog.findChild(QDateEdit,"data_ac")
	#today = QDate.currentDate()
	#data_ac.setDate(today)	
	largh_max = dialog.findChild(QLineEdit,"largh_max")
	largh_min = dialog.findChild(QLineEdit,"largh_min")
	lungh = dialog.findChild(QLineEdit,"lungh")
	lungh_vuo = dialog.findChild(QLineEdit,"lungh_vuo")
	n_aggreg = dialog.findChild(QLineEdit,"n_aggreg")
	n_manuf = dialog.findChild(QLineEdit,"n_manuf")
	el_ferrov = dialog.findChild(QLineEdit,"el_ferrov")
	el_pont = dialog.findChild(QLineEdit,"el_pont")
	el_tunn = dialog.findChild(QLineEdit,"el_tunn")
	el_pont_at = dialog.findChild(QLineEdit,"el_pont_at")
	el_muri = dialog.findChild(QLineEdit,"el_muri")
	pendenza = dialog.findChild(QLineEdit,"pendenza")
	zona_ms = dialog.findChild(QComboBox,"zona_ms")
	inst_name = dialog.findChild(QLabel,"inst_name")
	inst_fran = dialog.findChild(QCheckBox,"inst_fran")
	inst_liq = dialog.findChild(QCheckBox,"inst_liq")
	inst_fag = dialog.findChild(QCheckBox,"inst_fag")
	inst_ced = dialog.findChild(QCheckBox,"inst_ced")
	inst_cav = dialog.findChild(QCheckBox,"inst_cav")	
	tipo_infra = dialog.findChild(QComboBox,"tipo_infra")
	localita = dialog.findChild(QComboBox,"localita")
	cod_local = dialog.findChild(QLineEdit,"cod_local")
	pav_per = dialog.findChild(QComboBox,"pav_per")
	ost_disc = dialog.findChild(QComboBox,"ost_disc")
	morf = dialog.findChild(QComboBox,"morf")
	acq_sup = dialog.findChild(QComboBox,"acq_sup")
	alluvio = dialog.findChild(QComboBox,"alluvio")
	strade_a = dialog.findChild(QCheckBox,"strade_a")
	strade_b = dialog.findChild(QCheckBox,"strade_b")
	strade_c = dialog.findChild(QCheckBox,"strade_c")
	strade_d = dialog.findChild(QCheckBox,"strade_d")
	strade_e = dialog.findChild(QCheckBox,"strade_e")
	strade_f = dialog.findChild(QCheckBox,"strade_f")
	alert_ac = dialog.findChild(QLabel,"text_alert_ac")

	alert_ac.hide()
	inst_name.hide()
	inst_fran.hide()
	inst_liq.hide()
	inst_fag.hide()
	inst_ced.hide()
	inst_cav.hide()

	help_button = dialog.findChild(QPushButton, "help_button")
	help_button.clicked.connect(lambda: webbrowser.open('https://www.youtube.com/watch?v=drs3COLtML8'))
	help_button.setEnabled(False) #to delete

	button_box = dialog.findChild(QDialogButtonBox, "button_box")
	button_box.setEnabled(False)
	check_campi = [str(dialog.findChild(QComboBox,"localita").currentText()), str(dialog.findChild(QComboBox,"tipo_infra").currentText()), 
	dialog.findChild(QLineEdit,"ID_infra").text(), dialog.findChild(QLineEdit,"largh_max").text(), dialog.findChild(QLineEdit,"largh_min").text(),
	dialog.findChild(QLineEdit,"lungh").text(), dialog.findChild(QLineEdit,"lungh_vuo").text(), str(dialog.findChild(QComboBox,"pav_per").currentText()), 
	str(dialog.findChild(QComboBox,"ost_disc").currentText()), dialog.findChild(QLineEdit,"n_aggreg").text(), dialog.findChild(QLineEdit,"n_manuf").text(), 
	dialog.findChild(QLineEdit,"pendenza").text(), str(dialog.findChild(QComboBox,"morf").currentText()), str(dialog.findChild(QComboBox,"acq_sup").currentText()), 
	str(dialog.findChild(QComboBox,"alluvio").currentText())]
	check_value = []
	check_box = [dialog.findChild(QCheckBox,"strade_a").isChecked(), dialog.findChild(QCheckBox,"strade_b").isChecked(), dialog.findChild(QCheckBox,"strade_c").isChecked(), 
	dialog.findChild(QCheckBox,"strade_d").isChecked(), dialog.findChild(QCheckBox,"strade_e").isChecked(), dialog.findChild(QCheckBox,"strade_f").isChecked()]
	check_result = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	for y in check_box:
		if y is True:
			value_campi = 1
			check_result.append(value_campi)
		else:
			value_campi = 0
			check_result.append(value_campi)

	campi = sum(check_value)
	boxes = sum(check_result)
	if (campi > 14) and (boxes > 0):
		button_box.setEnabled(True)
	else:
		button_box.setEnabled(False)

	ID_infra.textEdited.connect(lambda: disableButton(button_box,dialog))
	largh_max.textEdited.connect(lambda: disableButton(button_box,dialog))
	largh_min.textEdited.connect(lambda: disableButton(button_box,dialog))
	localita.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	tipo_infra.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	lungh.textChanged.connect(lambda: disableButton(button_box,dialog))
	lungh_vuo.textChanged.connect(lambda: disableButton(button_box,dialog))
	pav_per.textChanged.connect(lambda: disableButton(button_box,dialog))
	ost_disc.textChanged.connect(lambda: disableButton(button_box,dialog))
	n_aggreg.textChanged.connect(lambda: disableButton(button_box,dialog))
	n_manuf.textChanged.connect(lambda: disableButton(button_box,dialog))
	pendenza.textChanged.connect(lambda: disableButton(button_box,dialog))
	morf.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	acq_sup.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	alluvio.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	strade_a.stateChanged.connect(lambda: disableButton(button_box,dialog))
	strade_b.stateChanged.connect(lambda: disableButton(button_box,dialog))
	strade_c.stateChanged.connect(lambda: disableButton(button_box,dialog))
	strade_d.stateChanged.connect(lambda: disableButton(button_box,dialog))
	strade_e.stateChanged.connect(lambda: disableButton(button_box,dialog))
	strade_f.stateChanged.connect(lambda: disableButton(button_box,dialog))
	localita.currentIndexChanged.connect(lambda: update_localita(dialog, cod_local, localita))
	ID_infra.editingFinished.connect(lambda: zero_digit(ID_infra, alert_ac, 10))
	largh_max.textEdited.connect(lambda: update_valore(largh_max))
	largh_min.textEdited.connect(lambda: update_valore(largh_min))
	lungh.textEdited.connect(lambda: update_valore(lungh))
	lungh_vuo.textEdited.connect(lambda: update_valore(lungh_vuo))
	n_aggreg.textEdited.connect(lambda: update_valore(n_aggreg))
	n_manuf.textEdited.connect(lambda: update_valore(n_manuf))
	el_ferrov.textEdited.connect(lambda: update_valore(el_ferrov))
	el_pont.textEdited.connect(lambda: update_valore(el_pont))
	el_tunn.textEdited.connect(lambda: update_valore(el_tunn))
	el_pont_at.textEdited.connect(lambda: update_valore(el_pont_at))
	el_muri.textEdited.connect(lambda: update_valore(el_muri))
	pendenza.textEdited.connect(lambda: update_valore(pendenza))
	largh_max.editingFinished.connect(lambda: alert_larg(dialog))
	largh_min.editingFinished.connect(lambda: alert_larg(dialog))
	lungh.editingFinished.connect(lambda: alert_larg_2(dialog))
	lungh_vuo.editingFinished.connect(lambda: alert_larg_2(dialog))
	zona_ms.currentIndexChanged.connect(lambda: disableInstab(dialog))


def disableButton(button_box,dialog):
	check_campi = [str(dialog.findChild(QComboBox,"localita").currentText()), str(dialog.findChild(QComboBox,"tipo_infra").currentText()), 
	dialog.findChild(QLineEdit,"ID_infra").text(), dialog.findChild(QLineEdit,"largh_max").text(), dialog.findChild(QLineEdit,"largh_min").text(),
	dialog.findChild(QLineEdit,"lungh").text(), dialog.findChild(QLineEdit,"lungh_vuo").text(), str(dialog.findChild(QComboBox,"pav_per").currentText()), 
	str(dialog.findChild(QComboBox,"ost_disc").currentText()), dialog.findChild(QLineEdit,"n_aggreg").text(), dialog.findChild(QLineEdit,"n_manuf").text(), 
	dialog.findChild(QLineEdit,"pendenza").text(), str(dialog.findChild(QComboBox,"morf").currentText()), str(dialog.findChild(QComboBox,"acq_sup").currentText()), 
	str(dialog.findChild(QComboBox,"alluvio").currentText())]
	check_value = []
	check_box = [dialog.findChild(QCheckBox,"strade_a").isChecked(), dialog.findChild(QCheckBox,"strade_b").isChecked(), dialog.findChild(QCheckBox,"strade_c").isChecked(), 
	dialog.findChild(QCheckBox,"strade_d").isChecked(), dialog.findChild(QCheckBox,"strade_e").isChecked(), dialog.findChild(QCheckBox,"strade_f").isChecked()]
	check_result = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	for y in check_box:
		if y is True:
			value_campi = 1
			check_result.append(value_campi)
		else:
			value_campi = 0
			check_result.append(value_campi)

	campi = sum(check_value)
	boxes = sum(check_result)
	if (campi > 14) and (boxes > 0):
		button_box.setEnabled(True)
	else:
		button_box.setEnabled(False)


def zero_digit(campo,alert,n):
	a = len(campo.text())
	if a < n:
		b = n - a
		c = ('0'*b) + campo.text()
		campo.setText(c)
		alert.hide()
	elif a > n:
		campo.setText("")
		alert.show()


def update_valore(value):
	value.setText(re.sub('[^0-9]','', value.text()))


def alert_larg(dialog):
	largh_max = dialog.findChild(QLineEdit,"largh_max")
	largh_min = dialog.findChild(QLineEdit,"largh_min")
	if (largh_max.text() != '') and (largh_min.text() != ''):
		if int(largh_min.text()) > int(largh_max.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the '15 MINIMA' field is greater than the value of the '14 MASSIMA' field!")
			largh_min.setText('')
			largh_max.setText('')


def alert_larg_2(dialog):
	lungh = dialog.findChild(QLineEdit,"lungh")
	lungh_vuo = dialog.findChild(QLineEdit,"lungh_vuo")
	if (lungh.text() != '') and (lungh_vuo.text() != ''):
		if int(lungh_vuo.text()) > int(lungh.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the '17 LUNGHEZZA TRATTO STRADALE SENZA AGGREGATIE UNITA' ISOLATE INTERFERENTI' field is greater than the value of the '16 LUNGHEZZA COMPLESSIVA' field!")
			lungh_vuo.setText('')
			lungh.setText('')


def disableInstab(dialog):
	zona_ms = dialog.findChild(QComboBox,"zona_ms")
	inst_name = dialog.findChild(QLabel,"inst_name")
	inst_fran = dialog.findChild(QCheckBox,"inst_fran")
	inst_liq = dialog.findChild(QCheckBox,"inst_liq")
	inst_fag = dialog.findChild(QCheckBox,"inst_fag")
	inst_ced = dialog.findChild(QCheckBox,"inst_ced")
	inst_cav = dialog.findChild(QCheckBox,"inst_cav")
	if zona_ms.currentText() == "3 - Instabile":
		inst_name.show()
		inst_fran.show()
		inst_liq.show()
		inst_fag.show()
		inst_ced.show()
		inst_cav.show()
		inst_fran.setEnabled(True)
		inst_liq.setEnabled(True)
		inst_fag.setEnabled(True)
		inst_ced.setEnabled(True)
		inst_cav.setEnabled(True)
	else:
		inst_fran.setChecked(False)
		inst_fran.setEnabled(False)
		inst_liq.setChecked(False)
		inst_liq.setEnabled(False)
		inst_fag.setChecked(False)
		inst_fag.setEnabled(False)
		inst_ced.setChecked(False)
		inst_ced.setEnabled(False)
		inst_cav.setChecked(False)
		inst_cav.setEnabled(False)


def update_localita(dialog, cod_local, localita):
	localita = dialog.findChild(QComboBox,"localita")
	cod_local = dialog.findChild(QLineEdit,"cod_local")
	TipoIndagine = str(localita.currentText().strip()).split("  -  ")[1]
	cod_local.setText(TipoIndagine)