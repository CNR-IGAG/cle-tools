# -*- coding: utf-8 -*-
#-------------------------------------------------------------------------------
# Name:		cle_cl_as.py
# Author:	  Tarquini E.
# Created:	 22-09-2018
#-------------------------------------------------------------------------------

from PyQt4.QtCore import *
from PyQt4.QtGui import *
from qgis.utils import *
from qgis.gui import *
from qgis.core import *
from qgis.PyQt.QtWidgets import *
import webbrowser, re


def cl_as(dialog, layer, feature):
	#data_as = dialog.findChild(QDateEdit,"data_as")
	#today = QDate.currentDate()
	#data_as.setDate(today)
	sezione = dialog.findChild(QLineEdit,"sezione")
	ID_aggr = dialog.findChild(QLineEdit,"ID_aggr")
	ID_area = dialog.findChild(QLineEdit,"ID_area")
	ID_infra_a = dialog.findChild(QLineEdit,"ID_infra_a")
	ID_infra_b = dialog.findChild(QLineEdit,"ID_infra_b")
	ID_infra_c = dialog.findChild(QLineEdit,"ID_infra_c")
	ID_infra_d = dialog.findChild(QLineEdit,"ID_infra_d")
	n_unita = dialog.findChild(QLineEdit,"n_unita")
	n_edif = dialog.findChild(QLineEdit,"n_edif")
	n_edif_gl = dialog.findChild(QLineEdit,"n_edif_gl")
	n_murat = dialog.findChild(QLineEdit,"n_murat")
	n_ca = dialog.findChild(QLineEdit,"n_ca")
	n_altre = dialog.findChild(QLineEdit,"n_altre")
	altezza = dialog.findChild(QLineEdit,"altezza")
	superf = dialog.findChild(QLineEdit,"superf")
	piani_min = dialog.findChild(QLineEdit,"piani_min")
	piani_max = dialog.findChild(QLineEdit,"piani_max")
	lungh_fron = dialog.findChild(QLineEdit,"lungh_fron")
	us_interf = dialog.findChild(QLineEdit,"us_interf")
	zona_ms = dialog.findChild(QComboBox,"zona_ms")
	inst_name = dialog.findChild(QLabel,"inst_name")
	inst_fran = dialog.findChild(QCheckBox,"inst_fran")
	inst_liq = dialog.findChild(QCheckBox,"inst_liq")
	inst_fag = dialog.findChild(QCheckBox,"inst_fag")
	inst_ced = dialog.findChild(QCheckBox,"inst_ced")
	inst_cav = dialog.findChild(QCheckBox,"inst_cav")
	localita = dialog.findChild(QComboBox,"localita")
	cod_local = dialog.findChild(QLineEdit,"cod_local")
	conn_volte = dialog.findChild(QComboBox,"conn_volte")
	conn_rifus = dialog.findChild(QComboBox,"conn_rifus")
	regol_1 = dialog.findChild(QComboBox,"regol_1")
	regol_2 = dialog.findChild(QComboBox,"regol_2")
	regol_3 = dialog.findChild(QComboBox,"regol_3")
	regol_4 = dialog.findChild(QComboBox,"regol_4")
	regol_5 = dialog.findChild(QComboBox,"regol_5")
	vuln_1 = dialog.findChild(QComboBox,"vuln_1")
	vuln_2 = dialog.findChild(QComboBox,"vuln_2")
	vuln_3 = dialog.findChild(QComboBox,"vuln_3")
	vuln_4 = dialog.findChild(QComboBox,"vuln_4")
	vuln_5 = dialog.findChild(QComboBox,"vuln_5")
	vuln_6 = dialog.findChild(QComboBox,"vuln_6")
	vuln_6 = dialog.findChild(QComboBox,"vuln_6")
	rinfor_1 = dialog.findChild(QComboBox,"rinfor_1")
	rinfor_2 = dialog.findChild(QComboBox,"rinfor_2")
	morf = dialog.findChild(QComboBox,"morf")
	alluvio = dialog.findChild(QComboBox,"alluvio")
	alert_as = dialog.findChild(QLabel,"text_alert_as")
	alert_ae = dialog.findChild(QLabel,"text_alert_ae")
	alert_ac = dialog.findChild(QLabel,"text_alert_ac")

	alert_as.hide()
	alert_ae.hide()
	alert_ac.hide()
	inst_name.hide()
	inst_fran.hide()
	inst_liq.hide()
	inst_fag.hide()
	inst_ced.hide()
	inst_cav.hide()

	help_button = dialog.findChild(QPushButton, "help_button")
	help_button.clicked.connect(lambda: webbrowser.open('https://www.youtube.com/watch?v=drs3COLtML8'))
	help_button.setEnabled(False) #to delete

	button_box = dialog.findChild(QDialogButtonBox, "button_box")
	button_box.setEnabled(False)
	check_campi = [dialog.findChild(QLineEdit,"ID_aggr").text(), dialog.findChild(QLineEdit,"n_unita").text(), dialog.findChild(QLineEdit,"n_edif").text(), 
	dialog.findChild(QLineEdit,"altezza").text(), dialog.findChild(QLineEdit,"superf").text(), dialog.findChild(QLineEdit,"piani_min").text(), 
	dialog.findChild(QLineEdit,"piani_max").text(), dialog.findChild(QLineEdit,"lungh_fron").text(), dialog.findChild(QLineEdit,"us_interf").text(),
	str(dialog.findChild(QComboBox,"conn_volte").currentText()), str(dialog.findChild(QComboBox,"conn_rifus").currentText()), str(dialog.findChild(QComboBox,"regol_1").currentText()), 
	str(dialog.findChild(QComboBox,"regol_2").currentText()), str(dialog.findChild(QComboBox,"regol_3").currentText()), str(dialog.findChild(QComboBox,"regol_4").currentText()), 
	str(dialog.findChild(QComboBox,"regol_5").currentText()), str(dialog.findChild(QComboBox,"vuln_1").currentText()), str(dialog.findChild(QComboBox,"vuln_2").currentText()), 
	str(dialog.findChild(QComboBox,"vuln_3").currentText()), str(dialog.findChild(QComboBox,"vuln_4").currentText()), str(dialog.findChild(QComboBox,"vuln_5").currentText()), 
	str(dialog.findChild(QComboBox,"vuln_6").currentText()), str(dialog.findChild(QComboBox,"vuln_6").currentText()), str(dialog.findChild(QComboBox,"rinfor_1").currentText()), 
	str(dialog.findChild(QComboBox,"rinfor_2").currentText()), str(dialog.findChild(QComboBox,"morf").currentText()), str(dialog.findChild(QComboBox,"alluvio").currentText())]
	check_value = []
	check_infra = [dialog.findChild(QLineEdit,"ID_area").text(), dialog.findChild(QLineEdit,"ID_infra_a").text(), dialog.findChild(QLineEdit,"ID_infra_b").text(), 
	dialog.findChild(QLineEdit,"ID_infra_c").text(), dialog.findChild(QLineEdit,"ID_infra_d").text()]
	check_result = []
	check_us = [dialog.findChild(QLineEdit,"n_murat").text(), dialog.findChild(QLineEdit,"n_ca").text(), dialog.findChild(QLineEdit,"n_altre").text()]
	check_tot = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	for y in check_infra:
		if len(y) > 0:
			value_campi = 1
			check_result.append(value_campi)
		else:
			value_campi = 0
			check_result.append(value_campi)

	for z in check_us:
		if len(z) > 0:
			value_campi = 1
			check_tot.append(value_campi)
		else:
			value_campi = 0
			check_tot.append(value_campi)

	campi = sum(check_value)
	infra = sum(check_result)
	n_us = sum(check_tot)
	if (campi > 26) and (infra > 0) and (n_us > 0):
		button_box.setEnabled(True)
	else:
		button_box.setEnabled(False)

	ID_aggr.textEdited.connect(lambda: disableButton(button_box,dialog))
	n_unita.textEdited.connect(lambda: disableButton(button_box,dialog))
	n_edif.textEdited.connect(lambda: disableButton(button_box,dialog))
	altezza.textEdited.connect(lambda: disableButton(button_box,dialog))
	superf.textEdited.connect(lambda: disableButton(button_box,dialog))
	piani_min.textEdited.connect(lambda: disableButton(button_box,dialog))
	piani_max.textEdited.connect(lambda: disableButton(button_box,dialog))
	lungh_fron.textEdited.connect(lambda: disableButton(button_box,dialog))
	us_interf.textEdited.connect(lambda: disableButton(button_box,dialog))
	conn_volte.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	conn_rifus.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	regol_1.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	regol_2.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	regol_3.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	regol_4.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	regol_5.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_1.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_2.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_3.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_4.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_5.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	vuln_6.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	rinfor_1.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	rinfor_2.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	morf.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	alluvio.currentIndexChanged.connect(lambda: disableButton(button_box,dialog))
	ID_area.textEdited.connect(lambda: disableButton(button_box,dialog))
	ID_infra_a.textEdited.connect(lambda: disableButton(button_box,dialog))
	ID_infra_b.textEdited.connect(lambda: disableButton(button_box,dialog))
	ID_infra_c.textEdited.connect(lambda: disableButton(button_box,dialog))
	ID_infra_d.textEdited.connect(lambda: disableButton(button_box,dialog))
	n_murat.textEdited.connect(lambda: disableButton(button_box,dialog))
	n_ca.textEdited.connect(lambda: disableButton(button_box,dialog))
	n_altre.textEdited.connect(lambda: disableButton(button_box,dialog))
	localita.currentIndexChanged.connect(lambda: update_localita(dialog, cod_local, localita))
	sezione.textEdited.connect(lambda: update_valore(sezione))
	ID_aggr.editingFinished.connect(lambda: zero_digit(ID_aggr, alert_as, 10, 1))
	ID_area.editingFinished.connect(lambda: zero_digit(ID_area, alert_ae, 10, 0))
	ID_infra_a.editingFinished.connect(lambda: zero_digit(ID_infra_a, alert_ac, 10, 0))
	ID_infra_b.editingFinished.connect(lambda: zero_digit(ID_infra_b, alert_ac, 10, 0))
	ID_infra_c.editingFinished.connect(lambda: zero_digit(ID_infra_c, alert_ac, 10, 0))
	ID_infra_d.editingFinished.connect(lambda: zero_digit(ID_infra_d, alert_ac, 10, 0))
	n_unita.textEdited.connect(lambda: update_valore(n_unita))
	n_edif.textEdited.connect(lambda: update_valore(n_edif))
	n_edif_gl.textEdited.connect(lambda: update_valore(n_edif_gl))
	n_murat.textEdited.connect(lambda: update_valore(n_murat))
	n_ca.textEdited.connect(lambda: update_valore(n_ca))
	n_altre.textEdited.connect(lambda: update_valore(n_altre))
	altezza.textEdited.connect(lambda: update_valore(altezza))
	superf.textEdited.connect(lambda: update_valore(superf))
	piani_min.textEdited.connect(lambda: update_valore(piani_min))
	piani_max.textEdited.connect(lambda: update_valore(piani_max))
	lungh_fron.textEdited.connect(lambda: update_valore(lungh_fron))
	us_interf.textEdited.connect(lambda: update_valore(us_interf))
	n_unita.editingFinished.connect(lambda: alert_us_1(dialog))
	n_edif.editingFinished.connect(lambda: alert_us_1(dialog))
	n_edif_gl.editingFinished.connect(lambda: alert_us_1(dialog))
	n_unita.editingFinished.connect(lambda: alert_us_2(dialog))
	n_murat.editingFinished.connect(lambda: alert_us_2(dialog))
	n_ca.editingFinished.connect(lambda: alert_us_2(dialog))
	n_altre.editingFinished.connect(lambda: alert_us_2(dialog))
	piani_min.editingFinished.connect(lambda: alert_us_3(dialog))
	piani_max.editingFinished.connect(lambda: alert_us_3(dialog))
	zona_ms.currentIndexChanged.connect(lambda: disableInstab(dialog))


def disableButton(button_box,dialog):
	check_campi = [dialog.findChild(QLineEdit,"ID_aggr").text(), dialog.findChild(QLineEdit,"n_unita").text(), dialog.findChild(QLineEdit,"n_edif").text(), 
	dialog.findChild(QLineEdit,"altezza").text(), dialog.findChild(QLineEdit,"superf").text(), dialog.findChild(QLineEdit,"piani_min").text(), 
	dialog.findChild(QLineEdit,"piani_max").text(), dialog.findChild(QLineEdit,"lungh_fron").text(), dialog.findChild(QLineEdit,"us_interf").text(),
	str(dialog.findChild(QComboBox,"conn_volte").currentText()), str(dialog.findChild(QComboBox,"conn_rifus").currentText()), str(dialog.findChild(QComboBox,"regol_1").currentText()), 
	str(dialog.findChild(QComboBox,"regol_2").currentText()), str(dialog.findChild(QComboBox,"regol_3").currentText()), str(dialog.findChild(QComboBox,"regol_4").currentText()), 
	str(dialog.findChild(QComboBox,"regol_5").currentText()), str(dialog.findChild(QComboBox,"vuln_1").currentText()), str(dialog.findChild(QComboBox,"vuln_2").currentText()), 
	str(dialog.findChild(QComboBox,"vuln_3").currentText()), str(dialog.findChild(QComboBox,"vuln_4").currentText()), str(dialog.findChild(QComboBox,"vuln_5").currentText()), 
	str(dialog.findChild(QComboBox,"vuln_6").currentText()), str(dialog.findChild(QComboBox,"vuln_6").currentText()), str(dialog.findChild(QComboBox,"rinfor_1").currentText()), 
	str(dialog.findChild(QComboBox,"rinfor_2").currentText()), str(dialog.findChild(QComboBox,"morf").currentText()), str(dialog.findChild(QComboBox,"alluvio").currentText())]
	check_value = []
	check_infra = [dialog.findChild(QLineEdit,"ID_area").text(), dialog.findChild(QLineEdit,"ID_infra_a").text(), dialog.findChild(QLineEdit,"ID_infra_b").text(), 
	dialog.findChild(QLineEdit,"ID_infra_c").text(), dialog.findChild(QLineEdit,"ID_infra_d").text()]
	check_result = []
	check_us = [dialog.findChild(QLineEdit,"n_murat").text(), dialog.findChild(QLineEdit,"n_ca").text(), dialog.findChild(QLineEdit,"n_altre").text()]
	check_tot = []

	for x in check_campi:
		if len(x) > 0:
			value_campi = 1
			check_value.append(value_campi)
		else:
			value_campi = 0
			check_value.append(value_campi)

	for y in check_infra:
		if len(y) > 0:
			value_campi = 1
			check_result.append(value_campi)
		else:
			value_campi = 0
			check_result.append(value_campi)

	for z in check_us:
		if len(z) > 0:
			value_campi = 1
			check_tot.append(value_campi)
		else:
			value_campi = 0
			check_tot.append(value_campi)

	campi = sum(check_value)
	infra = sum(check_result)
	n_us = sum(check_tot)
	if (campi > 26) and (infra > 0) and (n_us > 0):
		button_box.setEnabled(True)
	else:
		button_box.setEnabled(False)


def zero_digit(campo,alert,n,m):
	a = len(campo.text())
	if a < n:
		b = n - a
		if m == 0:
			c = ('0'*b) + campo.text()
		elif m == 1:
			c = ('0'*b) + campo.text() + '00'
		campo.setText(c)
		alert.hide()
	elif a > n:
		campo.setText("")
		alert.show()


def update_valore(value):
	value.setText(re.sub('[^0-9]','', value.text()))


def alert_us_1(dialog):
	n_unita = dialog.findChild(QLineEdit,"n_unita")
	n_edif = dialog.findChild(QLineEdit,"n_edif")
	n_edif_gl = dialog.findChild(QLineEdit,"n_edif_gl")
	if (n_unita.text() != '') and (n_edif.text() != ''):
		if int(n_edif.text()) > int(n_unita.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the '11 NUMERO US CON FUZIONI STRATEGICHE' field is greater than the value of the '10 NUMERO TOTALI UNITA' STRUTTURALI' field!")
			n_edif.setText('')
			n_unita.setText('')
	if (n_unita.text() != '') and (n_edif_gl.text() != ''):
		if int(n_edif_gl.text()) > int(n_unita.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the '12 NUMERO US CARATTERIZZATE DA GRANDI LUCI' field is greater than the value of the '10 NUMERO TOTALI UNITA' STRUTTURALI' field!")
			n_edif_gl.setText('')
			n_unita.setText('')


def alert_us_2(dialog):
	n_unita = dialog.findChild(QLineEdit,"n_unita")
	n_murat = dialog.findChild(QLineEdit,"n_murat")
	n_ca = dialog.findChild(QLineEdit,"n_ca")
	n_altre = dialog.findChild(QLineEdit,"n_altre")
	if (n_unita.text() != '') and (n_murat.text() != '') and (n_ca.text() != '') and (n_altre.text() != ''):
		if not int(n_unita.text()) == int(n_murat.text()) + int(n_ca.text()) + int(n_altre.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of '10 NUMERO TOTALI UNITA' STRUTTURALI' must be equal to the sum of '13 MURATURA', '14 C.A.' and '15 ALTRE STRUTTURE' field!")
			n_murat.setText('')
			n_ca.setText('')
			n_altre.setText('')


def alert_us_3(dialog):
	piani_min = dialog.findChild(QLineEdit,"piani_min")
	piani_max = dialog.findChild(QLineEdit,"piani_max")
	if (piani_min.text() == '') and (piani_max.text() == ''):
		pass
	elif (piani_min.text() != '') and (piani_max.text() != ''):
		if int(piani_min.text()) > int(piani_max.text()):
			QMessageBox.warning(None, u'WARNING!', u"The value of the '18 NUMERI PIANI MINIMO' field is greater than the value of the '19 NUMERO PIANI MASSIMO' field!")
			piani_min.setText('')
			piani_max.setText('')


def disableInstab(dialog):
	zona_ms = dialog.findChild(QComboBox,"zona_ms")
	inst_name = dialog.findChild(QLabel,"inst_name")
	inst_fran = dialog.findChild(QCheckBox,"inst_fran")
	inst_liq = dialog.findChild(QCheckBox,"inst_liq")
	inst_fag = dialog.findChild(QCheckBox,"inst_fag")
	inst_ced = dialog.findChild(QCheckBox,"inst_ced")
	inst_cav = dialog.findChild(QCheckBox,"inst_cav")
	if zona_ms.currentText() == "3 - Instabile":
		inst_name.show()
		inst_fran.show()
		inst_liq.show()
		inst_fag.show()
		inst_ced.show()
		inst_cav.show()
		inst_fran.setEnabled(True)
		inst_liq.setEnabled(True)
		inst_fag.setEnabled(True)
		inst_ced.setEnabled(True)
		inst_cav.setEnabled(True)
	else:
		inst_fran.setChecked(False)
		inst_fran.setEnabled(False)
		inst_liq.setChecked(False)
		inst_liq.setEnabled(False)
		inst_fag.setChecked(False)
		inst_fag.setEnabled(False)
		inst_ced.setChecked(False)
		inst_ced.setEnabled(False)
		inst_cav.setChecked(False)
		inst_cav.setEnabled(False)


def update_localita(dialog, cod_local, localita):
	localita = dialog.findChild(QComboBox,"localita")
	cod_local = dialog.findChild(QLineEdit,"cod_local")
	TipoIndagine = str(localita.currentText().strip()).split("  -  ")[1]
	cod_local.setText(TipoIndagine)