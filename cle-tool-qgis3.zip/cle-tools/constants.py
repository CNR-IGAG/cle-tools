# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QVariant

POSIZIONE = {"Comune del progetto":["BasiDati","Comune","id_com"], "Infrastrutture di accessibilita'/connessione":["CLE","CL_AC","ID_AC"], "Aree di emergenza":["CLE","CL_AE","ID_AE"],
             "Aggregati strutturali":["CLE","CL_AS","ID_AS"], "Edifici strategici":["CLE","CL_ES","ID_ES"], "Unita' strutturali":["CLE","CL_US","ID_US"]}

LISTA_LAYER = ["Comune del progetto", "Limiti comunali", "Infrastrutture di accessibilita'/connessione", "Aree di emergenza", "Aggregati strutturali", "Edifici strategici", "Unita' strutturali"]
