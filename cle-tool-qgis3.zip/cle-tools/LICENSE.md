CLE Tools * Copyright (c) 2019 Emanuele Tarquini, Gianluca Carbone, Giuseppe Cosentino, Francesco Pennica

Licensed under the terms of GNU GPL v3.0 (or any layer)
http://www.gnu.org/copyleft/gpl.html

CREDITS:
- Videoguides developed with Youtube (https://www.youtube.com);
- Toolbar icons and windows icons have been designed by plugin authors;
- 'CNR' logo, 'IGAG' logo, 'labGIS' logo, 'DPC' logo, 'Conferenza regioni e provincie autonome' logo and 'Regioni' logos belong to their respective owners who retain all rights in law;
- WMS Basemaps came from "Geoportale Nazionale" (http://www.pcn.minambiente.it/mattm/) [CC BY-NC-SA 3.0 IT];
- Administrative boundaries came from "Istituto nazionale di statistica - ISTAT" (https://www.istat.it/) [CC BY-SA 3.0 IT];
- Geodatabase was developed with Spatialite DB [GNU GPL v2.0].